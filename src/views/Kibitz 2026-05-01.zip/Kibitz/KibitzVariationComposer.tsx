/*
 * Copyright (C)  Online-Go.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import * as React from "react";
import * as data from "@/lib/data";
import { GobanController } from "@/lib/GobanController";
import { pgettext } from "@/lib/translate";
import "./KibitzVariationComposer.css";

interface KibitzVariationComposerProps {
    controller: GobanController;
    onSubmit: (controller: GobanController) => void;
    showSubmitButton?: boolean;
}

export function KibitzVariationComposer({
    controller,
    onSubmit,
    showSubmitButton = true,
}: KibitzVariationComposerProps): React.ReactElement {
    const [variationName, setVariationName] = React.useState(controller.variation_name);
    const isAnonymous = !!data.get("config.user")?.anonymous;

    React.useEffect(() => {
        const syncVariationName = (name: string) => {
            setVariationName(name);
        };

        controller.on("variation_name", syncVariationName);
        setVariationName(controller.variation_name);

        return () => {
            controller.off("variation_name", syncVariationName);
        };
    }, [controller]);

    return (
        <div className="KibitzVariationComposer">
            <div className="KibitzVariationComposer-controls">
                <input
                    type="text"
                    className="form-control"
                    placeholder={pgettext(
                        "Placeholder for naming a kibitz variation before posting it",
                        "Variation name...",
                    )}
                    value={variationName}
                    onChange={controller.updateVariationName}
                    onKeyDown={(event) => {
                        if (event.key === "Enter" && !isAnonymous) {
                            event.preventDefault();
                            onSubmit(controller);
                        }
                    }}
                    disabled={isAnonymous}
                />
                {showSubmitButton ? (
                    <button
                        type="button"
                        className="sm"
                        onClick={() => onSubmit(controller)}
                        disabled={isAnonymous}
                    >
                        {pgettext("Button label for posting a kibitz variation", "Post variation")}
                    </button>
                ) : null}
            </div>
            {isAnonymous ? (
                <div className="KibitzVariationComposer-disabled-note">
                    {pgettext(
                        "Message shown below the kibitz variation composer when posting is disabled",
                        "Need to be logged in to add variation",
                    )}
                </div>
            ) : null}
        </div>
    );
}
